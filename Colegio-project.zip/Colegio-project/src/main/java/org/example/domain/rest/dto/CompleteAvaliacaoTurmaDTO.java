package org.example.domain.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompleteAvaliacaoTurmaDTO {

    private Integer avaliacao;
    private Integer Turma;
}
